package com.alibou.security.auth;

import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminController {
	
	@GetMapping("/hello1")
	public ResponseEntity<String> sayHello()
	{
		return ResponseEntity.ok("Hello");
		
	}
	
	@GetMapping("/hello2")
	public ResponseEntity<String> sayHello2()
	{
		return ResponseEntity.ok("Hello2");
		
	}
	
	
	
	

}
