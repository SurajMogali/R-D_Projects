package com.alibou.security.auth;

public class AuthenticationResponse2 {
}
