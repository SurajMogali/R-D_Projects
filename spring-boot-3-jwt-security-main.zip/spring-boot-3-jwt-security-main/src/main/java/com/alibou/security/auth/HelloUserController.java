package com.alibou.security.auth;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/user")
public class HelloUserController {



		@GetMapping("/hellouser1")
		public ResponseEntity<String> sayHello() {
			return ResponseEntity.ok("Hello User1");

		}

		@GetMapping("/hello2")
		public ResponseEntity<String> sayHello2() {
			return ResponseEntity.ok("Hello User2");

		}

	}


